export interface Payment {
  date: string;
  amount: number;
}

export interface CustomerImages {
  personal: string;
  resFront: string;
  resBack: string;
  idFront: string;
  idBack: string;
}

export interface GuarantorImages {
  personal?: string;
  idFront?: string;
  idBack?: string;
  resFront?: string;
  resBack?: string;
}

export interface Guarantor {
  name: string;
  phone: string;
  address: string;
  images?: GuarantorImages;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  productName: string;
  productSerial: string;
  totalAmount: number;
  upfront: number;
  monthlyAmount: number;
  remainingAmount: number;
  dueDay: number;
  images: CustomerImages;
  payments: Payment[];
  status: 'active' | 'done';
  dateAdded: string;
  hasGuarantor?: boolean;
  guarantor?: Guarantor;
}

export interface SystemCredentials {
  username?: string;
  password?: string;
  fullName?: string;
  age?: string;
  phone?: string;
}

// --- INDEXEDDB DATA SERVICE ENGINGE ---

const DB_NAME = "AlAqsatOfflineDb";
const DB_VERSION = 1;

let dbInstance: IDBDatabase | null = null;

function getDB(): Promise<IDBDatabase> {
  if (dbInstance) return Promise.resolve(dbInstance);

  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);

    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains("customers")) {
        db.createObjectStore("customers", { keyPath: "id" });
      }
      if (!db.objectStoreNames.contains("system")) {
        db.createObjectStore("system", { keyPath: "id" });
      }
    };

    request.onsuccess = () => {
      dbInstance = request.result;
      resolve(dbInstance);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

// --- LOCAL DATA ACCESS OPERATIONS ---

async function getAllCustomersFromIndexedDB(): Promise<Customer[]> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readonly");
    const store = transaction.objectStore("customers");
    const request = store.getAll();

    request.onsuccess = () => {
      resolve(request.result || []);
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function saveCustomerToIndexedDB(customer: Customer): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.put(customer);

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function deleteCustomerFromIndexedDB(id: string): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.delete(id);

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function getSystemCredentialsFromIndexedDB(): Promise<SystemCredentials | null> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("system", "readonly");
    const store = transaction.objectStore("system");
    const request = store.get("credentials");

    request.onsuccess = () => {
      const result = request.result;
      if (result && result.creds) {
        resolve(result.creds);
      } else {
        resolve(null);
      }
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

async function saveSystemCredentialsToIndexedDB(creds: SystemCredentials): Promise<void> {
  const db = await getDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction("system", "readwrite");
    const store = transaction.objectStore("system");
    const request = store.put({ id: "credentials", creds });

    request.onsuccess = () => {
      resolve();
    };

    request.onerror = () => {
      reject(request.error);
    };
  });
}

// --- PUBSUB STATE MANANGEMENT ---

const customersListeners: ((customers: Customer[]) => void)[] = [];
const credentialsListeners: ((creds: SystemCredentials | null) => void)[] = [];

async function notifyCustomersListeners() {
  try {
    const list = await getAllCustomersFromIndexedDB();
    // Sort customers so that newer entries are displayed gracefully or keep existing order
    for (const callback of customersListeners) {
      callback(list);
    }
  } catch (err) {
    console.error("Error notifying customers listeners:", err);
  }
}

async function notifyCredentialsListeners() {
  try {
    const creds = await getSystemCredentialsFromIndexedDB();
    for (const callback of credentialsListeners) {
      callback(creds);
    }
  } catch (err) {
    console.error("Error notifying credentials listeners:", err);
  }
}

/**
 * Saves or updates a customer in IndexedDB local store
 */
export async function saveCustomer(customer: Customer): Promise<void> {
  await saveCustomerToIndexedDB(customer);
  await notifyCustomersListeners();
}

/**
 * Deletes a customer from IndexedDB local store
 */
export async function deleteCustomerFromDb(id: string): Promise<void> {
  await deleteCustomerFromIndexedDB(id);
  await notifyCustomersListeners();
}

/**
 * Subscribes to real-time changes of the customers list in IndexedDB
 */
export function subscribeToCustomers(callback: (customers: Customer[]) => void): () => void {
  customersListeners.push(callback);
  
  // Call immediately with current data
  getAllCustomersFromIndexedDB()
    .then((list) => {
      if (customersListeners.includes(callback)) {
        callback(list);
      }
    })
    .catch((err) => console.error("Error fetching customers for subscription:", err));

  return () => {
    const index = customersListeners.indexOf(callback);
    if (index !== -1) {
      customersListeners.splice(index, 1);
    }
  };
}

/**
 * Saves or updates system credentials in IndexedDB local store
 */
export async function saveSystemCredentials(creds: SystemCredentials): Promise<void> {
  await saveSystemCredentialsToIndexedDB(creds);
  await notifyCredentialsListeners();
}

/**
 * Subscribes to real-time changes of system credentials in IndexedDB
 */
export function subscribeToSystemCredentials(callback: (creds: SystemCredentials | null) => void): () => void {
  credentialsListeners.push(callback);

  // Call immediately with current data
  getSystemCredentialsFromIndexedDB()
    .then((creds) => {
      if (credentialsListeners.includes(callback)) {
        callback(creds);
      }
    })
    .catch((err) => console.error("Error fetching credentials for subscription:", err));

  return () => {
    const index = credentialsListeners.indexOf(callback);
    if (index !== -1) {
      credentialsListeners.splice(index, 1);
    }
  };
}

// --- BACKUP & RESTORE SYSTEM ---

export interface BackupData {
  version: number;
  exportDate: string;
  customers: Customer[];
  credentials: SystemCredentials | null;
}

/**
 * Exports all IndexedDB data into a single JSON backup string
 */
export async function exportBackupData(): Promise<string> {
  const customers = await getAllCustomersFromIndexedDB();
  const credentials = await getSystemCredentialsFromIndexedDB();
  
  const backup: BackupData = {
    version: 1,
    exportDate: new Date().toISOString(),
    customers,
    credentials
  };
  
  return JSON.stringify(backup);
}

/**
 * Restores data from a JSON backup string into the local IndexedDB, clearing old entries
 */
export async function importBackupData(jsonString: string): Promise<void> {
  const data = JSON.parse(jsonString) as BackupData;
  if (!data || typeof data !== "object") {
    throw new Error("تنسيق ملف النسخ الاحتياطي غير صالح");
  }
  
  if (!Array.isArray(data.customers)) {
    throw new Error("ملف النسخ الاحتياطي لا يحتوي على قائمة عملاء صالحة");
  }

  const db = await getDB();
  
  // 1. Clear existing customers
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("customers", "readwrite");
    const store = transaction.objectStore("customers");
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });

  // 2. Clear existing system credentials
  await new Promise<void>((resolve, reject) => {
    const transaction = db.transaction("system", "readwrite");
    const store = transaction.objectStore("system");
    const request = store.clear();
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error);
  });

  // 3. Write imported customers
  if (data.customers.length > 0) {
    const customerTx = db.transaction("customers", "readwrite");
    const customerStore = customerTx.objectStore("customers");
    for (const customer of data.customers) {
      customerStore.put(customer);
    }
    await new Promise<void>((resolve, reject) => {
      customerTx.oncomplete = () => resolve();
      customerTx.onerror = () => reject(customerTx.error);
    });
  }

  // 4. Write imported credentials if present
  if (data.credentials) {
    await saveSystemCredentialsToIndexedDB(data.credentials);
  }

  // 5. Notify all listeners to update current screens immediately
  await notifyCustomersListeners();
  await notifyCredentialsListeners();
}
