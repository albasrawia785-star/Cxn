import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { User, Lock, Save, Key, RefreshCw, AlertCircle, Download, Upload, ShieldCheck } from "lucide-react";
import { saveSystemCredentials, SystemCredentials, exportBackupData, importBackupData } from "../firebase";

interface SettingsScreenProps {
  currentCredentials: SystemCredentials | null;
  onCredentialsChange: (newCreds: SystemCredentials) => void;
  showToast: (msg: string, type: "success" | "danger" | "info") => void;
}

export default function SettingsScreen({
  currentCredentials,
  onCredentialsChange,
  showToast
}: SettingsScreenProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  // Initialize form with current credentials
  useEffect(() => {
    if (currentCredentials) {
      setUsername(currentCredentials.username || "ali");
      setPassword(currentCredentials.password || "0");
    } else {
      setUsername("ali");
      setPassword("0");
    }
  }, [currentCredentials]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!username.trim()) {
      showToast("❌ يرجى إدخال اسم مستخدم صالح", "danger");
      return;
    }
    if (!password.trim()) {
      showToast("❌ يرجى إدخال كلمة مرور صالحة", "danger");
      return;
    }

    setIsSaving(true);
    try {
      const newCreds: SystemCredentials = {
        username: username.trim(),
        password: password.trim()
      };

      // Save to local IndexedDB
      await saveSystemCredentials(newCreds);

      // Notify parent to update local state immediately
      onCredentialsChange(newCreds);

      showToast("✨ تم حفظ بيانات الدخول محلياً بنجاح!", "success");
    } catch (error) {
      console.error("Error saving credentials:", error);
      showToast("❌ عذراً، فشل حفظ البيانات محلياً.", "danger");
    } finally {
      setIsSaving(false);
    }
  };

  const handleExport = async () => {
    try {
      const backupStr = await exportBackupData();
      const blob = new Blob([backupStr], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      const dateStr = new Date().toISOString().split('T')[0];
      a.href = url;
      a.download = `alaqsat_backup_${dateStr}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      showToast("✨ تم تصدير النسخة الاحتياطية بنجاح وحفظها في جهازك!", "success");
    } catch (error) {
      console.error("Export error:", error);
      showToast("❌ عذراً، فشل تصدير النسخة الاحتياطية", "danger");
    }
  };

  const handleImport = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const confirmImport = window.confirm(
      "تنبيه هام: استيراد النسخة الاحتياطية سيقوم بحذف جميع البيانات الحالية في جهازك واستبدالها ببيانات الملف. هل أنت متأكد من الاستمرار؟"
    );
    if (!confirmImport) {
      e.target.value = "";
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const jsonString = event.target?.result as string;
        await importBackupData(jsonString);
        showToast("✨ تم استيراد واسترجاع البيانات كاملة بنجاح!", "success");
      } catch (error) {
        console.error("Import error:", error);
        showToast("❌ فشل استيراد الملف. تأكد من أنه ملف نسخة احتياطية صالح.", "danger");
      } finally {
        e.target.value = "";
      }
    };
    reader.onerror = () => {
      showToast("❌ فشل قراءة الملف المحدد", "danger");
      e.target.value = "";
    };
    reader.readAsText(file);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      className="h-full flex flex-col overflow-hidden text-right"
      dir="rtl"
    >
      <div className="flex-shrink-0 space-y-4 pb-2">
        {/* Title Header */}
        <div className="bg-gradient-to-l from-[#13223F] to-slate-900 rounded-[28px] p-5 text-white shadow-lg space-y-2 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-32 h-32 bg-white/5 rounded-full blur-2xl -translate-x-8 -translate-y-8" />
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-xl translate-x-4 translate-y-4" />
          
          <h2 className="text-xl font-extrabold flex items-center gap-2.5">
            <span>⚙️ إعدادات النظام والأمان</span>
          </h2>
          <p className="text-xs text-indigo-200/90 leading-relaxed">
            من هنا يمكنك تخصيص بيانات الدخول محلياً وإدارة النسخ الاحتياطي للنظام لضمان حماية بياناتك والقدرة على استعادتها في أي وقت.
          </p>
        </div>

        {/* Info Notice card */}
        <div className="bg-amber-50 border border-amber-200/60 rounded-2xl p-4 flex gap-3 items-start shadow-sm">
          <AlertCircle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-extrabold text-amber-900">ملاحظة أمان هامة</h4>
            <p className="text-[11px] text-amber-800 leading-relaxed font-semibold">
              يتم حفظ جميع البيانات محلياً 100% داخل هذا الجهاز بشكل آمن للغاية. عند تغيير كلمة المرور أو اسم المستخدم، سيتم إلغاء البيانات القديمة فوراً (بما فيها رمز "ali" و"0" الافتراضي).
            </p>
          </div>
        </div>
      </div>

      {/* Form Credentials Card */}
      <div className="flex-1 overflow-y-auto pb-4 px-1 bg-white rounded-3xl p-6 border border-slate-100 shadow-[0_8px_30px_rgba(0,0,0,0.04)] space-y-6 -webkit-overflow-scrolling: touch;">
        
        <form onSubmit={handleSave} className="space-y-6">
          {/* Username Field */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
              <User className="w-4 h-4 text-[#13223F]" />
              <span>اسم المستخدم الجديد:</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="مثال: admin"
                className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-[#13223F]/5 focus:border-[#13223F] outline-none transition-all text-sm font-semibold text-slate-800 text-right"
              />
              <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
                <User className="w-4 h-4" />
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-medium block pr-1">
              يُسْتَخْدَم هذا الاسم لتسجيل الدخول إلى لوحة التحكم بدلاً من "ali".
            </span>
          </div>

          {/* Password Field */}
          <div className="space-y-2">
            <label className="text-xs font-extrabold text-slate-700 flex items-center gap-1.5 pr-1">
              <Lock className="w-4 h-4 text-[#13223F]" />
              <span>كلمة المرور الجديدة:</span>
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="أدخل كلمة المرور الجديدة"
                className="w-full h-12 px-4 pr-11 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white focus:ring-4 focus:ring-[#13223F]/5 focus:border-[#13223F] outline-none transition-all text-sm font-semibold text-slate-800 text-right font-mono"
              />
              <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-slate-400">
                <Key className="w-4 h-4" />
              </div>
            </div>
            <span className="text-[10px] text-slate-400 font-medium block pr-1">
              يجب أن تكون كلمة مرور قوية يسهل عليك تذكرها لتأمين لوحة البيانات.
            </span>
          </div>

          {/* Action Button */}
          <button
            type="submit"
            disabled={isSaving}
            className="w-full h-12 bg-[#13223F] hover:bg-[#0B1E3D] disabled:bg-slate-400 text-white font-extrabold rounded-xl text-sm transition-all cursor-pointer flex items-center justify-center gap-2 shadow-md hover:shadow-lg active:scale-[0.98]"
          >
            {isSaving ? (
              <>
                <RefreshCw className="w-5 h-5 animate-spin" />
                <span>جاري الحفظ...</span>
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                <span>حفظ التعديلات والأمان</span>
              </>
            )}
          </button>
        </form>

        {/* Backup and Restore Section */}
        <div className="border-t border-slate-100 pt-6 space-y-4">
          <div className="flex items-center gap-2 text-slate-800 font-extrabold">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            <span>💾 إدارة النسخ الاحتياطي والاستعادة (أوفلاين)</span>
          </div>
          
          <p className="text-[11px] text-slate-500 leading-relaxed font-bold">
            هذا النظام يعمل بالكامل أوفلاين (مستقل 100%). نوصي بشدة بتصدير نسخة احتياطية من بياناتك بشكل دوري وحفظها خارج الجهاز لمنع فقدانها في حال تعطل المتصفح أو مسح ذاكرته المؤقتة.
          </p>

          <div className="grid grid-cols-2 gap-3 pt-1">
            {/* Export Button */}
            <button
              type="button"
              onClick={handleExport}
              className="h-12 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/40 text-emerald-800 font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98]"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>تصدير نسخة احتياطية</span>
            </button>

            {/* Import Button */}
            <label className="h-12 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200/40 text-[#13223F] font-extrabold rounded-xl text-xs transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.98] text-center">
              <Upload className="w-4 h-4 text-[#13223F]" />
              <span>استيراد نسخة احتياطية</span>
              <input
                type="file"
                accept=".json"
                className="hidden"
                onChange={handleImport}
              />
            </label>
          </div>
        </div>

      </div>
    </motion.div>
  );
}
